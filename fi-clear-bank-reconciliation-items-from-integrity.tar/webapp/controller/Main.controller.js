sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageToast",
  "sap/m/SearchField",
  "sap/ui/model/SimpleType",
  "sap/ui/model/ValidateException",
  "sap/ui/table/Column",
  "sap/m/Label",
  "sap/m/Text",
  "sap/m/ColumnListItem",
  "sap/m/Column",
  "sap/ui/model/Filter",
  "sap/ui/model/type/String",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageBox",
  "sap/ui/core/Fragment",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/BusyIndicator"
], function (Controller, MessageToast, SearchField, SimpleType, ValidateException, UIColumn, Label, Text, ColumnListItem, MColumn, Filter, TypeString, FilterOperator, MessageBox, Fragment, JSONModel, BusyIndicator) {
  "use strict";

  return Controller.extend("com.wl.fi.clearbankrncl.controller.Main", {
    onInit() {
      this._oMultiInputDocumentType = this.byId("_IDGenInput");
      var oViewModel = new JSONModel({
        isLocalFileSelected: true,
        isServerFileSelected: false,
        showLocalFile: true,
        showServerFile: false,
        serverPath: ""
      });

      this.getView().setModel(oViewModel);
    },
    // Handle radio button selection for choosing between local and server file
    onRadioButtonSelect: function (oEvent) {
      var oViewModel = this.getView().getModel();
      var sSelectedText = oEvent.getSource().getText();

      if (sSelectedText === "Local file name") {
        oViewModel.setProperty("/showLocalFileOption", true);
        oViewModel.setProperty("/showServerFileOption", false);
        oViewModel.setProperty("/showLocalFile", true);
        oViewModel.setProperty("/showServerFile", false);
      } else if (sSelectedText === "Server file name") {
        oViewModel.setProperty("/showLocalFileOption", false);
        oViewModel.setProperty("/showServerFileOption", true);
        oViewModel.setProperty("/showLocalFile", false);
        oViewModel.setProperty("/showServerFile", true);
      }
    },
    // Open value help dialog for document type selection
    onDocumentTypeValueHelpRequested: function () {
      if (!this._oDocumentDialog) {
        // Create the dialog from the XML fragment and bind it to the controller
        this._oDocumentDialog = sap.ui.xmlfragment("com.wl.fi.clearbankrncl.fragment.Document", this);
        // Add the dialog as a dependent to the view
        this.getView().addDependent(this._oDocumentDialog);
      }
      this._oDocumentDialog.open();
    },
    // Retrieve the search value entered by the user
    handleSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
      // Create a filter to match the search value with the 'Blart' field (Document Type ID)
			var oFilter = new Filter("Blart", FilterOperator.Contains, sValue);
      // Get the binding of the list items inside the value help dialog
			var oBinding = oEvent.getSource().getBinding("items");
      // Apply the filter to the list, updating the displayed items dynamically
			oBinding.filter([oFilter]);
		},
    handleValueHelpClose: function (oEvent) {
      // Clear the selected plant in the local model
      this.getOwnerComponent().getModel(" ");

      // Get the binding for the items in the event's source
      var oBinding = oEvent.getSource().getBinding("items");
      // If there is a binding, clear any applied filters
      if (oBinding) {
        oBinding.filter([]);
      }

      // Retrieve the selected contexts from the event
      var aContexts = oEvent.getParameter("selectedContexts");
      // Check if there are any selected contexts
      if (aContexts && aContexts.length) {
        var oDataObj = aContexts[0].getObject();
        console.log(" oDataObj", oDataObj)
        var documenttype = oDataObj.Blart
        // Set the Production Order value in the input field
        this.byId("_IDGenInput").setValue(documenttype);
      }
    },


    // Handle file selection and validate file type
    onFileChange: function (oEvent) {
      var oFileUploader = oEvent.getSource();
      this.getView().byId("fileUploader").setValueState("None");
      this.getView().byId("fileUploader").setValueStateText("");
      var oFile = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
      var oFiletype = oFile.type
      if (oFiletype == "text/plain") {
        this._oFile = oFile;

      } else {
        var oResourceModel = this.getView().getModel("i18n"),
          oBundle = oResourceModel.getResourceBundle();
        sap.m.MessageToast.show(oBundle.getText("Validtextfile"));
        oFileUploader.setValue("");
      }
      if (oEvent.getParameters().files[0].size === 0) {
        MessageToast.show("No data.");
        oFileUploader.setValue("");
      }
    },
    // Validate if a file is uploaded before processing
    validationCheck: function () {
      var fileUploader = this.getView().byId("fileUploader").getValue();

      if (fileUploader === "") {
        this.getView().byId("fileUploader").setValueState("Error");
        this.getView().byId("fileUploader").setValueStateText("Please upload some text file.");
        this.getView().byId("fileUploader").focus();
        return true;
      }
      else {
        this.getView().byId("fileUploader").setValueState("None");
        this.getView().byId("fileUploader").setValueStateText("");
        this.getView().byId("fileUploader").focus();
      }
    },
    // on click of upload or post it will read the file data and store the data in json and 
    // send the data to backend using post call
    // Handle file upload process
    onUploadPress: function () {
      console.log("onUploadPress function called");

      var validValue = this.validationCheck();
      if (validValue === true) {
        var oResourceModel = this.getView().getModel("i18n"),
          oBundle = oResourceModel.getResourceBundle();
        sap.m.MessageToast.show(oBundle.getText("messageValidationFailed"));
        return;
      }

      if (this._oFile) {
        var reader = new FileReader();
        var that = this;

        reader.onload = function (e) {
          var fileContent = e.target.result;
          var payloadFinal = that.parseFileContent(fileContent);

          if (payloadFinal && payloadFinal.length > 0) {
            that.onBulkPosting(payloadFinal);
            MessageToast.show("File processed successfully.");
          } else {
            var oResourceModel = this.getView().getModel("i18n"),
              oBundle = oResourceModel.getResourceBundle();
            sap.m.MessageToast.show(oBundle.getText("NoValiddata"));
            // MessageToast.show("No valid data found in the file.");
          }
        };

        reader.readAsText(this._oFile);
      } else {
        var oResourceModel = this.getView().getModel("i18n"),
          oBundle = oResourceModel.getResourceBundle();
        sap.m.MessageToast.show(oBundle.getText("Nofileselected"));
       
      }
    },
    // Parse file content and convert it to JSON format
    parseFileContent: function (fileContent) {

      // Split the content by lines        
      var aDataLines = fileContent.split("\n");
      var aParsedData = [];
      var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
        pattern: "yyyyMMdd"
      });
      //var datajson={};
      //try{
      aDataLines.forEach(function (line) {
        var datajson = {};
        var fields = line.split("|");
        if (fields.length > 1) { // Ensure the line has data


          datajson.header = fields[0] && fields[0].trim() !== "" ? fields[0].trim() : "";
          datajson.posting_date = fields[1] && fields[1].trim() !== ""
            ? dateFormat.format(new Date(fields[1].substring(0, 4), fields[1].substring(4, 6) - 1, fields[1].substring(6, 8)))
            : "";
          datajson.comp_code = fields[2] && fields[2].trim() !== "" ? fields[2].trim() : "";

          // Assign Acc_no correctly based on header condition
          if (datajson.header === "D") {
            datajson.Acc_no = fields[3] && fields[3].trim() !== "" ? fields[3].trim() : "";
            datajson.posting_key = fields[4] && fields[4].trim() !== "" ? fields[4].trim() : "";
            datajson.cost_center = fields[5] && fields[5].trim() !== "" ? fields[5].trim() : "";
            datajson.profit_center = fields[6] && fields[6].trim() !== "" ? fields[6].trim() : "";
            datajson.trad_ptnr = fields[7] && fields[7].trim() !== "" ? fields[7].trim() : "";
            datajson.amount = fields[8] && fields[8].trim() !== "" ? fields[8].trim() : "";
            datajson.tax_code = fields[9] && fields[9].trim() !== "" ? fields[9].trim() : "";
            datajson.assignment = fields[10] && fields[10].trim() !== "" ? fields[10].trim() : "";

            // Correct item_text field assignment
            datajson.item_text = fields[11] && fields[11].trim() !== "" ? fields[11].trim() : "";

            // Correct currency field assignment
            datajson.currency = fields[12] && fields[12].trim() !== "" ? fields[12].trim() : "";

            datajson.account_2 = fields[13] && fields[13].trim() !== "" ? fields[13].trim() : "";
            datajson.posting_key_2 = fields[14] && fields[14].trim() !== "" ? fields[14].trim() : "";

            aParsedData.push(datajson);
          }
        }

      });


      return aParsedData;
    },
    onUploadComplete: function (oEvent) {
      var sResponse = oEvent.getParameter("response");
      if (sResponse) {
        //this.onResetOther();                
        MessageToast.show("Upload complete: " + sResponse);
      }
    },
    onTypeMissmatch: function (oEvent) {
      var oResourceModel = this.getView().getModel("i18n"),
        oBundle = oResourceModel.getResourceBundle();
      sap.m.MessageToast.show(oBundle.getText("textformatonly"));
      // MessageToast.show("Please enter file in text(txt) format only");
    },
    // Send parsed data to backend for processing
    onBulkPosting: function (finalPayload) {
      var that = this;
      var oModel = this.getOwnerComponent().getModel();
      var aDeferredGroups = oModel.getDeferredGroups();
      if (!aDeferredGroups.includes("gid")) {
        aDeferredGroups = aDeferredGroups.concat(["gid"]);
        oModel.setDeferredGroups(aDeferredGroups);
      }

      BusyIndicator.show();
      finalPayload.forEach(
        function (payload, idx) {
          //var oInput = finalPayload;
          oModel.create("/ZINTGR_RECON_TEST1", payload, {
            groupId: "gid",
            success: function (oData, oHdr) {
              if (oData.msgtype === 'E') {
                //MessageToast.show(oData.message);
                //MessageBox.error(oData.message);
              }
              //console.log("success-create");
            }.bind(this),
            error: function (oResponse, oHdr) {
              // MessageToast.show("Error in File");
              //console.log("error-create");
              //console.log(oResponse.responseText);
            }.bind(this),
          });
        }.bind(this)
      );

      //   oModel.submitChanges({
      //     groupId: "gid",
      //     success: function (oData, response) {
      //     try{
      //     var oMessage = JSON.parse(oData.__batchResponses[0].__changeResponses[0].headers["sap-message"]);                     

      //     if(oMessage.severity==="error"){
      //        // var oMessage = JSON.parse(oData.__batchResponses[0].__changeResponses[0].headers["sap-message"]);                     
      //         MessageBox.error(oMessage.message);
      //     }
      //     else if(oMessage.severity==="success"){
      //         //var oMessage = JSON.parse(oData.__batchResponses[0].__changeResponses[0].headers["sap-message"]);                     
      //         MessageBox.success(oMessage.message); 
      //     }
      //     else{
      //         MessageBox.error("No message received from server"); 
      //     }
      // }
      // catch(e){

      //         MessageBox.error("Error while reading the response"); 
      //     }
      //     //that.onReset();
      //     //MessageBox.show("success");
      //       BusyIndicator.hide();
      //     }.bind(this),
      //     error: function (oError) {

      //         try{
      //         var oMessageError = JSON.parse(oData.__batchResponses[0].__changeResponses[0].headers["sap-message"]);                     

      //         if(oMessageError.severity==="error"){
      //             MessageBox.error(oMessage.message);
      //        // MessageBox.error(oError.__batchResponses[0].__changeResponses[0].data.message); 
      //         } 
      //         else{
      //             MessageBox.error("No message received from server");
      //         }
      //     }               
      //         catch(e)
      //         {
      //             MessageBox.error("Error while reading the response");  
      //         }
      //        BusyIndicator.hide();
      //        //that.onReset();

      //     }.bind(this),
      //   });              

    }

  });
})



