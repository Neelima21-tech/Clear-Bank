sap.ui.define([
	"com/wl/fi/clearbankrncl/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
