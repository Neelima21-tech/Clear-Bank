/* global QUnit */

sap.ui.require(["com/wl/fi/clearbankrncl/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
